# BASIC BANKING SYSTEM
Made this project under internship offered by The Sparks Foundation(TSF) under #GRIPMAY21
In this project we can transfer money online and can view the transaction history for the same.
It is made using HTML, CSS, Javascript.
